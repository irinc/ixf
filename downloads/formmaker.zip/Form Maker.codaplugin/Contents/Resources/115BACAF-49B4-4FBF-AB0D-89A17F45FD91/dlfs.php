#!/usr/bin/php
<?php
$z = getenv('CODA_LINE_ENDING');

$input = "";

$fp = fopen("php://stdin", "r");
while ( $line = fgets($fp, 1024) )
	$input .= $line;
	
fclose($fp);

// Select Label Name
//    -Optgroup Name
//    Option Name
//    Option Name
//    *Selected Option Name
//    Option Name
// *Required Select Label Name
//    Option Name
//    Option Name

// split the list of labels into an array
$inputarray = explode($z,$input);

// iterate through the array
for($x=0; $x<count($inputarray); $x++) {
	
	// strip off an * (from the beginning), and whitespace, decode HTML entities and then encode any HTML entities that require it. This will be the label text
	$input2 = ltrim($inputarray[$x],'*');
	$input2 = trim($input2);
	$input2 = html_entity_decode($input2);
	$input2 = htmlspecialchars($input2);
	
	// convert the string to lower case and replace certain characters. this will be used for the id/name/label for.
	$a = strtolower($inputarray[$x]);
	$a = html_entity_decode($a);
	$character = array('@','#','$','%','&');
	$replace = array('at','number','dollar','percent','and');
	$b = str_ireplace($character,$replace,$a);
	// delete any characters that are not alphanumeric and any HTML entities. Replace all spaces with hyphens and trim any whitespace/leading/trailing hyphens
	$b = preg_replace('/[^a-zA-Z0-9 ]/','',$b);
	$b = preg_replace('/&.*?;/','',$b);
	$b = preg_replace('/ {1,10}/','-',$b);
	$b = trim($b,'-');

	// for 1st iteration we need to check required status and then create the first dl accordingly
	if($x == 0) {
		
		// check if the field is a required field by looking for an * at the beginning of the string. If yes then output required field markup, if not use regular markup
		if(preg_match('/^\*./',$inputarray[$x]) == 1) {
			echo '<dl class="required">
	<dt><span title="required" class="required-indicator">*</span> <label for="' . $b . '">' . $input2 . '</label></dt>
	<dd>
		<select aria-required="true" name="' . $b . '" id="' . $b . '">
';
		} else {
			echo '<dl>
	<dt><label for="' . $b . '">' . $input2 . '</label></dt>
	<dd>
		<select name="' . $b . '" id="' . $b . '">
';
		}
	} else {
		//Check if tabbed, else it is a label
		if(preg_match('/^\t./',$inputarray[$x]) == 1) {
			//Check if it has a '-', this is an OPTGROUP
			if(preg_match('/^-./',$input2) == 1) {
				$input2 = ltrim($input2,'-');
				echo '			<optgroup label=' . $input2 . ' />
';
			} else {
				//Check if the option is the selected item
				if(preg_match('/^\*./',$input2) == 1) {
					$input2 = ltrim($input2,'*');
					echo '			<option value="' . $b . '" selected="selected">' . $input2 . '</option>
';
				} else {
					echo '			<option value="' . $b . '">' . $input2 . '</option>
';
				}
			}
		} else {
			// check if the field is a required field by looking for an * at the beginning of the string. If yes then output required field markup, if not use regular markup
			if(preg_match('/^\*./',$inputarray[$x]) == 1) {
				echo '		</select>
	</dd>
</dl>
<dl class="required">
	<dt><span title="required" class="required-indicator">*</span> <label for="' . $b . '">' . $input2 . '</label></dt>
	<dd>
		<select aria-required="true" name="' . $b . '" id="' . $b . '">
';
			} else {
				echo '		</select>
	</dd>
</dl>
<dl>
	<dt><label for="' . $b . '">' . $input2 . '</label></dt>
	<dd>
		<select name="' . $b . '" id="' . $b . '">
';
			}
		}
	}
}

//Close the select and dl
echo '		</select>
	</dd>
</dl>
';

?>