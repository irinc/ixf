#!/usr/bin/php
<?php
$z = getenv('CODA_LINE_ENDING');

$input = "";

$fp = fopen("php://stdin", "r");
while ( $line = fgets($fp, 1024) )
	$input .= $line;
	
fclose($fp);

// split the list of labels into an array
$inputarray = explode($z,$input);

// iterate through the array
for($x=0; $x<count($inputarray); $x++) {
	
	// strip off an * (from the beginning), and whitespace, decode HTML entities and then encode any HTML entities that require it. This will be the label text
	$input2 = ltrim($inputarray[$x],'*');
	$input2 = trim($input2);
	$input2 = html_entity_decode($input2);
	$input2 = htmlspecialchars($input2);
	
	// convert the string to lower case and replace certain characters. this will be used for the id/name/label for.
	$a = strtolower($inputarray[$x]);
	$a = html_entity_decode($a);
	$character = array('@','#','$','%','&');
	$replace = array('at','number','dollar','percent','and');
	$b = str_ireplace($character,$replace,$a);
	// delete any characters that are not alphanumeric and any HTML entities. Replace all spaces with hyphens and trim any whitespace/leading/trailing hyphens
	$b = preg_replace('/[^a-zA-Z0-9 ]/','',$b);
	$b = preg_replace('/&.*?;/','',$b);
	$b = preg_replace('/ {1,10}/','-',$b);
	$b = trim($b,'-');

	// for 1st iteration we need to check required status and then create the first dl accordingly
	if($x == 0) {
		
		// check if the field is a required field by looking for an * at the beginning of the string. If yes then output required field markup, if not use regular markup
		if(preg_match('/^\*./',$inputarray[$x]) == 1) {
			echo '<dl>
	<dt class="required"><span title="required" class="required-indicator">*</span> ' . $input2 . '</dt>
	<dd class="options-vertical">
		<fieldset>
			<legend class="invisible">' . $input2 . '</legend>
';
			$id = $b;
			$req = 1;
		} else {
			echo '<dl>
	<dt>' . $input2 . '</dt>
	<dd class="options-vertical">
		<fieldset>
			<legend class="invisible">' . $input2 . '</legend>
';
			$id = $b;
			$req = 0;
		}
	} else {
		//Check if tabbed (radio values), else it is a label
		if(preg_match('/^\t./',$inputarray[$x]) == 1) {
			//Check if the radio is the selected
			if(preg_match('/^\*./',$input2) == 1) {
				$input2 = ltrim($input2,'*');
				echo '			<span class="ixf-option"><input';
				if($req == 1) {
					echo ' aria-required="true"';
				}
				echo ' name="' . $id . '" type="radio" value="" id="' . $id . '-' . $b . '" checked="checked" /> <label for="' . $id . '-' . $b . '">' . $input2 . '</label></span>
';
			} else {
				echo '			<span class="ixf-option"><input';
				if($req == 1) {
					echo ' aria-required="true"';
				}
				echo ' name="' . $id . '" type="radio" value="" id="' . $id . '-' . $b . '" /> <label for="' . $id . '-' . $b . '">' . $input2 . '</label></span>
';
			}
		} else {
			// check if the field is a required field by looking for an * at the beginning of the string. If yes then output required field markup, if not use regular markup
			if(preg_match('/^\*./',$inputarray[$x]) == 1) {
				echo '		</fieldset>
	</dd>
</dl>
<dl>
	<dt class="required"><span title="required" class="required-indicator">*</span> ' . $input2 . '</dt>
	<dd class="options-vertical">
		<fieldset>
			<legend class="invisible">' . $input2 . '</legend>
';
				$id = $b;
				$req = 1;
			} else {
				echo '		</fieldset>
	</dd>
</dl>
<dl>
	<dt>' . $input2 . '</dt>
	<dd class="options-vertical">
		<fieldset>
			<legend class="invisible">' . $input2 . '</legend>
';
			$id = $b;
			$req = 0;
			}
		}
	}
}

//Close the fieldset, dd and dl
echo '		</fieldset>
	</dd>
</dl>
';

?>