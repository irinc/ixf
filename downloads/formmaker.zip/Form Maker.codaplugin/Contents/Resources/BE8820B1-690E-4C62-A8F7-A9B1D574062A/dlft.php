#!/usr/bin/php
<?php
$z = getenv('CODA_LINE_ENDING');

$input = "";

$fp = fopen("php://stdin", "r");
while ( $line = fgets($fp, 1024) )
	$input .= $line;
	
fclose($fp);

// split the list of labels into an array
$inputarray = explode($z,$input);

// iterate through the array
foreach($inputarray as $i) {
	
	// strip off an * (from the beginning), and whitespace, decode HTML entities and then encode any HTML entities that require it. This will be the label text
	$input2 = ltrim($i,'*');
	$input2 = trim($input2);
	$input2 = html_entity_decode($input2);
	$input2 = htmlspecialchars($input2);
	
	// convert the string to lower case and replace certain characters. this will be used for the id/name/label for.
	$a = strtolower($i);
	$a = html_entity_decode($a);
	$character = array('@','#','$','%','&');
	$replace = array('at','number','dollar','percent','and');
	$b = str_ireplace($character,$replace,$a);
	// delete any characters that are not alphanumeric and any HTML entities. Replace all spaces with hyphens and trim any whitespace/leading/trailing hyphens
	$b = preg_replace('/[^a-zA-Z0-9 ]/','',$b);
	$b = preg_replace('/&.*?;/','',$b);
	$b = preg_replace('/ {1,10}/','-',$b);
	$b = trim($b,'-');
	
	// check if the field is a required field by looking for an * at the beginning of the string. If yes then output required field markup, if not use regular markup
	if(preg_match('/^\*./',$i) == 1) {
	
		echo '<dl class="required">
	<dt><span title="required" class="required-indicator">*</span> <label for="' . $b . '">' . $input2. '</label></dt>
	<dd><textarea aria-required="true" cols="" rows="" name="' . $b . '" id="' . $b . '">Enter your text here.</textarea></dd>
</dl>
';
		
	} else {
	
		echo '<dl>
	<dt><label for="' . $b . '">' . $input2 . '</label></dt>
	<dd><textarea cols="" rows="" name="' . $b . '" id="' . $b . '">Enter your text here.</textarea></dd>
</dl>
';
	
	}

}

?>